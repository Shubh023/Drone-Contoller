import serial
import sys
import time
import numpy as np
import pandas as pd
from datetime import datetime


COM_PORT = "/dev/cu.usbmodem1302"

baudrate = 115200

ser = serial.Serial(COM_PORT, baudrate)

Time, Roll, Output, LSpeed, RSpeed = 'Time', 'Roulis_Gyro', 'PID_Sortie', 'PWMGauche', 'PWMDroite'
global df
df = pd.DataFrame(columns=[Roll, Output, LSpeed, RSpeed])
while True:
    try:
        ser_bytes = ser.readline().decode('utf-8')
        L = ser_bytes.lstrip("b'").rstrip("\r\n'").split(';')
        fL = [float(i) for i in L]
        if len(fL) == 4:
            print(fL[0])
            df = df.append({Time: datetime.now(),
                            Roll: fL[0],
                            Output: fL[1],
                            LSpeed: fL[2],
                            RSpeed: fL[3]}, ignore_index=True)
    except:
        print(df)
        df.to_csv('KPID3.csv')
        print('Keyboard Error')
        break